"""
MPS Algorithm Package
Matrix-Parametrized Proximal Splitting for Sensor Network Localization
"""

from .mps_full_algorithm import (
    MatrixParametrizedProximalSplitting,
    MPSConfig,
    NetworkData,
    create_network_data
)

from .proximal_sdp import (
    ProximalADMMSolver,
    ProximalOperatorsPSD
)

from .sinkhorn_knopp import (
    SinkhornKnopp,
    MatrixParameterGenerator
)

from .vectorization import MatrixVectorizer

__version__ = "1.0.0"

__all__ = [
    # Main algorithm
    'MatrixParametrizedProximalSplitting',
    'MPSConfig',
    'NetworkData',
    'create_network_data',
    
    # Proximal operators
    'ProximalADMMSolver',
    'ProximalOperatorsPSD',
    
    # Matrix generation
    'SinkhornKnopp',
    'MatrixParameterGenerator',
    
    # Vectorization
    'MatrixVectorizer',
]


# Simplified API
class MPSAlgorithm:
    """Simplified API for MPS algorithm."""
    
    def __init__(self, gamma=0.999, alpha=10.0, **kwargs):
        """Initialize with key parameters."""
        self.gamma = gamma
        self.alpha = alpha
        self.kwargs = kwargs
    
    def solve(self, network, max_iterations=500):
        """Solve the localization problem."""
        config = MPSConfig(
            n_sensors=network.adjacency_matrix.shape[0],
            n_anchors=len(network.anchor_positions),
            dimension=2,
            gamma=self.gamma,
            alpha=self.alpha,
            max_iterations=max_iterations,
            tolerance=1e-6,
            communication_range=0.7,
            verbose=False,
            early_stopping=True,
            early_stopping_window=50,
            admm_iterations=100,
            admm_tolerance=1e-6,
            admm_rho=1.0,
            warm_start=True,
            parallel_proximal=False,
            use_2block=True,
            adaptive_alpha=False,
            carrier_phase_mode=False,
            **self.kwargs
        )
        
        mps = MatrixParametrizedProximalSplitting(config, network)
        return mps.run()


def create_network(n_sensors=30, n_anchors=6, noise=0.05, seed=None):
    """Quick network creation."""
    if seed is not None:
        import numpy as np
        np.random.seed(seed)
    
    return create_network_data(
        n_sensors=n_sensors,
        n_anchors=n_anchors,
        dimension=2,
        communication_range=0.7,
        measurement_noise=noise,
        carrier_phase=False
    )