#!/usr/bin/env python3
"""
Example usage of MPS algorithm for sensor network localization.
"""

import numpy as np
from mps_core.mps_full_algorithm import (
    MatrixParametrizedProximalSplitting,
    MPSConfig,
    NetworkData,
    create_network_data
)
import matplotlib.pyplot as plt


def main():
    """Run MPS algorithm example."""
    
    print("MPS Algorithm Example")
    print("=" * 50)
    
    # 1. Create synthetic network
    print("\n1. Creating network...")
    network = create_network_data(
        n_sensors=30,
        n_anchors=6,
        dimension=2,
        communication_range=0.7,
        measurement_noise=0.05,  # 5% noise as in paper
        carrier_phase=False
    )
    print(f"   - {30} sensors, {6} anchors")
    print(f"   - Communication range: 0.7")
    print(f"   - Measurement noise: 5%")
    
    # 2. Configure algorithm (paper's parameters)
    print("\n2. Configuring algorithm...")
    config = MPSConfig(
        n_sensors=30,
        n_anchors=6,
        dimension=2,
        gamma=0.999,           # Paper's value
        alpha=10.0,            # Paper's value
        max_iterations=500,    # More iterations for convergence
        tolerance=1e-6,
        communication_range=0.7,
        verbose=False,
        early_stopping=True,
        early_stopping_window=50,
        admm_iterations=100,
        admm_tolerance=1e-6,
        admm_rho=1.0,
        warm_start=True,       # Enable warm-starting
        parallel_proximal=False,
        use_2block=True,       # Use 2-block structure
        adaptive_alpha=False,
        carrier_phase_mode=False
    )
    print(f"   - γ = {config.gamma}")
    print(f"   - α = {config.alpha}")
    print(f"   - Max iterations = {config.max_iterations}")
    print(f"   - ADMM warm-start: {config.warm_start}")
    
    # 3. Run algorithm
    print("\n3. Running MPS algorithm...")
    mps = MatrixParametrizedProximalSplitting(config, network)
    result = mps.run()
    
    # 4. Calculate metrics
    final_positions = result['final_positions']
    true_positions = network.true_positions
    
    relative_error = np.linalg.norm(final_positions - true_positions, 'fro') / \
                    np.linalg.norm(true_positions, 'fro')
    
    mean_distance = np.mean([np.linalg.norm(final_positions[i] - true_positions[i])
                            for i in range(30)])
    
    # 5. Display results
    print("\n4. Results:")
    print(f"   - Iterations: {result['iterations']}")
    print(f"   - Converged: {result['converged']}")
    print(f"   - Relative error: {relative_error:.4f}")
    print(f"   - Mean distance: {mean_distance:.4f}")
    print(f"   - Final RMSE: {result['final_rmse']:.4f}")
    
    # Compare with paper
    print("\n5. Comparison with paper:")
    print(f"   - Paper reports: 0.05-0.10 relative error")
    print(f"   - Our result: {relative_error:.4f}")
    
    if relative_error <= 0.10:
        print("   ✓ SUCCESS! Matches paper's performance")
    elif relative_error <= 0.15:
        print("   ✓ Close to paper's performance")
    else:
        print("   ⚠ May need more iterations or parameter tuning")
    
    # 6. Visualize results
    print("\n6. Creating visualization...")
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # True positions
    ax = axes[0]
    ax.scatter(true_positions[:, 0], true_positions[:, 1], 
              c='blue', s=50, label='True', alpha=0.6)
    ax.scatter(network.anchor_positions[:, 0], network.anchor_positions[:, 1],
              c='red', s=100, marker='s', label='Anchors')
    ax.set_title('True Positions')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Estimated positions
    ax = axes[1]
    ax.scatter(final_positions[:, 0], final_positions[:, 1],
              c='green', s=50, label='Estimated', alpha=0.6)
    ax.scatter(network.anchor_positions[:, 0], network.anchor_positions[:, 1],
              c='red', s=100, marker='s', label='Anchors')
    
    # Draw error lines
    for i in range(30):
        ax.plot([true_positions[i, 0], final_positions[i, 0]],
               [true_positions[i, 1], final_positions[i, 1]],
               'k-', alpha=0.2, linewidth=0.5)
    
    ax.set_title(f'Estimated Positions (Error: {relative_error:.3f})')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.suptitle('MPS Algorithm Results')
    plt.tight_layout()
    plt.savefig('mps_results.png', dpi=150, bbox_inches='tight')
    print("   Saved to mps_results.png")
    
    # 7. Show convergence
    if 'history' in result and 'position_error' in result['history']:
        plt.figure(figsize=(8, 5))
        errors = result['history']['position_error']
        plt.plot(errors, 'b-', linewidth=2)
        plt.xlabel('Iteration')
        plt.ylabel('Position Error')
        plt.title('Convergence History')
        plt.grid(True, alpha=0.3)
        plt.savefig('mps_convergence.png', dpi=150, bbox_inches='tight')
        print("   Convergence plot saved to mps_convergence.png")
    
    print("\n" + "=" * 50)
    print("Example complete!")
    
    return result


if __name__ == "__main__":
    result = main()