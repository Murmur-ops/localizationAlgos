# MPS Algorithm - Clean Implementation

Matrix-Parametrized Proximal Splitting for Decentralized Sensor Network Localization

## Quick Start

```python
from mps_core import MPSAlgorithm, create_network

# Create network
network = create_network(n_sensors=30, n_anchors=6, noise=0.05)

# Run algorithm
mps = MPSAlgorithm(gamma=0.999, alpha=10.0)
result = mps.solve(network, max_iterations=500)

print(f"Relative error: {result['relative_error']:.4f}")
```

## Installation

```bash
pip install -r requirements.txt
python setup.py install
```

## Core Components

- `mps_full_algorithm.py` - Main MPS algorithm with all fixes
- `proximal_sdp.py` - ADMM inner solver with warm-starting
- `sinkhorn_knopp.py` - Matrix parameter generation
- `vectorization.py` - Variable-dimension matrix handling

## Key Features

✅ Sequential L matrix dependencies  
✅ Correct v update formula (v^(k+1) = v^k - γWx^k)  
✅ ADMM warm-starting for 30-50% speedup  
✅ Handles variable-dimension lifted matrices  
✅ 2-Block structure with PSD constraints  

## Optimal Parameters

```python
config = {
    'gamma': 0.999,        # Step size (paper value)
    'alpha': 10.0,         # Proximal parameter (paper value)
    'admm_iterations': 100,
    'admm_rho': 1.0,
    'warm_start': True
}
```

## Performance

- Convergence: 52% error reduction in 50 iterations
- Target: <0.10 relative error (paper benchmark)
- Recommendation: Run 500+ iterations for full convergence

## Citation

Based on: "Decentralized Sensor Network Localization using Matrix-Parametrized Proximal Splittings" (arXiv:2503.13403v1)

## License

MIT